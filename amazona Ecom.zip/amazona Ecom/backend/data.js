export default {
    products:[
        {
        _id: '1',
        name: 'Tshirt',
        category: 'Tshirts',
        image: '/images/tshirt1.jpg',
        price: 950,
        brand: 'Lacostte',
        rating: 4.5,
        numReviews: 10,
        countInStock: 6,
    },
    {
        _id: '2',
        name: 'White Tshirt',
        category: 'Tshirts',
        image: '/images/tshirt1.jpg',
        price: 750,
        brand: 'Lacostte',
        rating: 4.5,
        numReviews: 1,
        countInStock: 10,
    },
]
}